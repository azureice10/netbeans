package mainController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Koneksi {

   public Connection conn;
   public Statement stmn;

    public void koneksi() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/sia";
            String user = "root";
            String pass = "";
            conn = DriverManager.getConnection(url, user, pass);
            stmn = conn.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "Koneksi Gagal " + ex);
        } 
    }
}
