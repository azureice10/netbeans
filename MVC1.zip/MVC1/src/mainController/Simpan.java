package mainController;

import java.sql.*;
import javax.swing.JOptionPane;

public class Simpan {

    Connection con;
    Statement stat;
    String nip = null;
    String nama = null;
    String email = null;
    String password = null;

    public void simpanAkun(String n1, String n2, String n3) throws Exception {
        try {
            stat.executeUpdate("INSERT INTO dosen (nip, nama, email) VALUES ('" + n1 + "', '" + n2 + "','" + n3 + "');");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan " + ex);
            return;
        }
        JOptionPane.showMessageDialog(null, "Berhasil Disimpan");
    }
    
    public void simpanAkun(String n1, String n2, String n3, String n4) throws Exception {
        try {
            stat.executeUpdate("INSERT INTO dosen (nip, nama, email) VALUES ('" + n1 + "', '" + n2 + "','" + n3 + "');");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan " + ex);
            return;
        }
        JOptionPane.showMessageDialog(null, "Berhasil Disimpan");
    }
}

