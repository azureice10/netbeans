package mainModel;

public class Dosen {
    private String nip;
    private String nama;
    private String email;
    private String password;
    private String prikey;
    private String pubkey;

    public Dosen(String nip, String nama, String email, String password, String prikey, String pubkey) {
        this.nip = nip;
        this.nama = nama;
        this.email = email;
        this.password = password;
        this.prikey = prikey;
        this.pubkey = pubkey;
    }

    public Dosen(String nip, String nama, String email, String password) {
        this.nip = nip;
        this.nama = nama;
        this.email = email;
        this.password = password;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPrikey() {
        return prikey;
    }

    public void setPrikey(String prikey) {
        this.prikey = prikey;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
