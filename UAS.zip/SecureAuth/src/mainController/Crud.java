package mainController;

public interface Crud {

    public void createData();
    
    public void updateData();

    public void deleteData();
}
