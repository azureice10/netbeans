package mainController;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.crypto.SecretKey;

public class KeyStore {

    public static void simpankey() throws Exception {
        java.security.KeyStore ks = java.security.KeyStore.getInstance("JCEKS");
        String pass = "password";
        char[] pas = pass.toCharArray();
        ks.load(null, pas);
        SecretKey sk = EnkripsiAES.KeyAes();
        java.security.KeyStore.SecretKeyEntry entry = new java.security.KeyStore.SecretKeyEntry(sk);
        java.security.KeyStore.ProtectionParameter pp = new java.security.KeyStore.PasswordProtection(pas);
        try (FileOutputStream fos = new FileOutputStream("key.jks")) {
            ks.setEntry("alias", entry, pp);
            ks.store(fos, pas);
        }
    }

    public static SecretKey ambilKey() throws Exception {
        String pass = "password";
        char[] pas = pass.toCharArray();
        java.security.KeyStore ks = java.security.KeyStore.getInstance("JCEKS");
        ks.load(new FileInputStream("key.jks"), pas);
        java.security.KeyStore.ProtectionParameter pp
                = new java.security.KeyStore.PasswordProtection(pas);
        java.security.KeyStore.SecretKeyEntry en
                = (java.security.KeyStore.SecretKeyEntry) ks.getEntry("alias", pp);
        return en.getSecretKey();
    }
}
