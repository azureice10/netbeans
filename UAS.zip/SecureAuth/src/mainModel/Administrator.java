package mainModel;

public class Administrator extends User {
    
}
