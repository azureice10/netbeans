package mainModel;

public class Nasabah extends User{
    
}
