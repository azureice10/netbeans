package secureauth;

import java.sql.*;
import javax.swing.JOptionPane;

public class DbConnect {

    Connection conn;
    Statement stmn;

    public void setConnection() {
        try {
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://127.0.0.1/uas";
            String user = "root";
            String pass = "";
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);
            stmn = conn.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "Koneksi Gagal " + ex);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan " + ex);
        }
    }
}
