package secureauth;

import javax.swing.JOptionPane;
import mainViews.MainLogin;

public class SecureAuth {

    public static void main(String[] args) {
        // menampilkan form login
        try {
            MainLogin mainLogin = new MainLogin();
            mainLogin.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
